using Unity.VisualScripting;
using UnityEngine;

public class PlayManager : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        AddExp();
        AddItem();
        DoQuest();
    }

    public void AddExp()
    {

    }

    public void AddItem()
    {

    }

    public void DoQuest()
    {

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}

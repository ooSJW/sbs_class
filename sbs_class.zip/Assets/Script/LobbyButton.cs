using UnityEngine;

public partial class LobbyButton : MonoBehaviour // Data Field
{

}
public partial class LobbyButton : MonoBehaviour // Initialize
{
    private void Allocate()
    {

    }
    public void Initialize()
    {
        Allocate();
        Setup();
    }
    private void Setup()
    {

    }
}
public partial class LobbyButton : MonoBehaviour // 
{
 
}